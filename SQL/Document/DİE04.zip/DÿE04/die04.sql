create database batuhan44
use batuhan44

create table aracbilgiler
(

ID int,
ureticifirma nvarchar (50),
aracmodeli nvarchar (50),
alimtarihi DATETIME,
teslimtarihi DATETIME,
teslimenekadarvar DATETIME
)

insert into aracbilgiler(ID,ureticifirma,aracmodeli,alimtarihi) values (1,'BWM x7','X7 Jeep',GETDATE())
insert into aracbilgiler(ID,ureticifirma,aracmodeli,alimtarihi) values (2,'BWM x8','Businnes',GETDATE())
insert into aracbilgiler(ID,ureticifirma,aracmodeli,alimtarihi) values (3,'BWM x9','2012 Sports',GETDATE())

Select* from aracbilgiler


insert into aracbilgiler(ID,ureticifirma,aracmodeli,teslimtarihi) values (1,'BWM x7','X7 Jeep',DATEADD(DAY,20,GETDATE()))
insert into aracbilgiler(ID,ureticifirma,aracmodeli,teslimtarihi) values (2,'BWM x8','Businnes',DATEADD(MONTH,10,GETDATE()))
insert into aracbilgiler(ID,ureticifirma,aracmodeli,teslimtarihi) values (3,'BWM x9','2012 Sports',DATEADD(YEAR,2018,GETDATE()))

select teslimtarihi from aracbilgiler

insert into aracbilgiler(ID,ureticifirma,aracmodeli,alimtarihi) values (1,'BWM x7','X7 Jeep',DATEPART(DAY,GETDATE()))
insert into aracbilgiler(ID,ureticifirma,aracmodeli,alimtarihi) values (2,'BWM x8','Businnes',DATEPART(MONTH,GETDATE()))
insert into aracbilgiler(ID,ureticifirma,aracmodeli,alimtarihi) values (3,'BWM x9','2012 Sports',DATEPART(YEAR,GETDATE()))

select alimtarihi from aracbilgiler

SELECT DATEDIFF(month,alimtarihi,teslimtarihi) AS teslimenekadarvar From aracbilgiler
select TODATETIMEOFFSET(SYSDATETIMEOFFSET(),'-05:00')

	
	

select SYSDATETIME() 
select TODATETIMEOFFSET(SYSDATETIMEOFFSET(),'-05:00')


create table checkident
(
	id int primary key identity(1,1),
	firmasaati datetime default(getdate()),
	satisveteslimfark� int,
	teslimtarihiekle datetime,
	yillar int, 
)


insert into checkident (satisveteslimfark�,teslimtarihiekle,yillar) 
values(DATEDIFF(YEAR,'2010-02-01',GETDATE()),DATEADD(DAY,14,'2018-10-01'),DATEPART(YEAR,'2020-10-01'))

insert into checkident (satisveteslimfark�,teslimtarihiekle,yillar) 
values(DATEDIFF(YEAR,'2010-02-01',GETDATE()),DATEADD(DAY,14,'2018-10-01'),DATEPART(YEAR,'2020-10-01'))

insert into checkident (satisveteslimfark�,teslimtarihiekle,yillar) 
values(DATEDIFF(YEAR,'2010-02-01',GETDATE()),DATEADD(DAY,14,'2018-10-01'),DATEPART(YEAR,'2020-10-01'))

insert into checkident (satisveteslimfark�,teslimtarihiekle,yillar) 
values(DATEDIFF(YEAR,'2010-02-01',GETDATE()),DATEADD(DAY,14,'2018-10-01'),DATEPART(YEAR,'2020-10-01'))

insert into checkident(satisveteslimfark�,teslimtarihiekle,yillar) 
values(DATEDIFF(YEAR,'2010-02-01',GETDATE()),DATEADD(DAY,14,'2018-10-01'),DATEPART(YEAR,'2020-10-01'))


select*from checkident

DELETE FROM checkident WHERE id=4 

select*from checkident


DBCC CHECKIDENT (checkident, RESEED,3) 

insert into checkident (satisveteslimfark�,teslimtarihiekle,yillar) 
					   values(DATEDIFF(YEAR,'2010-02-01',GETDATE()),DATEADD(DAY,14,'2018-10-01'),DATEPART(YEAR,'2020-10-01'))
select*from checkident


DBCC CHECKIDENT (checkident, RESEED) 

insert into checkident (satisveteslimfark�,teslimtarihiekle,yillar) 
					   values(DATEDIFF(YEAR,'2010-02-01',GETDATE()),DATEADD(DAY,14,'2018-10-01'),DATEPART(YEAR,'2020-10-01'))


select*from checkident 

DBCC CHECKIDENT (checkidentkullanimi, NORESEED)

