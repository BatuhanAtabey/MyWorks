
create database batuhan5556
use batuhan5556


Create Schema felsefe
go

create table felsefe.ogrenci
(
ogrID int primary key identity(1,1),
ogrNo int,
ogrAd nvarchar(50),
ogrSoyad nvarchar(50),
)

create table felsefe.hoca
(
hocaID int primary key identity(1,1),
hocaNo int,
hocaAd nvarchar(50),
hocaSoyad nvarchar(50),

)

create table felsefe.ders
(
dersID int primary key identity(1,1),
dersNo int,
dersIsim nvarchar(50),

)

create table felsefe.notlar
(
notID int primary key identity(1,1),
ogrID int,
dersID int,
hocaID int,
Vize int,
Final int,
)

insert into felsefe.ogrenci(ogrAd,ogrSoyad,ogrNo)
values('Cem','Pusat',170111006)

insert into felsefe.ders(dersIsim,dersNo)
values('Felsefe',2)

insert into felsefe.hoca(hocaAd,hocaSoyad,hocaNo)
values('Mustafa','Atabey',1)

insert into felsefe.notlar(ogrID,dersID,hocaID,Vize,Final)
values(170111006,2,1,60,80)






Create Schema bilgisayar
go

create table bilgisayar.ogrenci
(
ogrID int primary key identity(1,1),
ogrNo int,
ogrAd nvarchar(50),
ogrSoyad nvarchar(50),
)

create table bilgisayar.hoca
(
hocaID int primary key identity(1,1),
hocaNo int,
hocaAd nvarchar(50),
hocaSoyad nvarchar(50),

)

create table bilgisayar.ders
(
dersID int primary key identity(1,1),
dersNo int,
dersIsim nvarchar(50),

)

create table bilgisayar.notlar
(
notID int primary key identity(1,1),
ogrID int,
dersID int,
hocaID int,
Vize int,
Final int,
)

insert into bilgisayar.ogrenci(ogrAd,ogrSoyad,ogrNo)
values('Batuhan','Atabey',170111006)

insert into bilgisayar.ders(dersIsim,dersNo)
values('Bilgisayar',2)

insert into bilgisayar.hoca(hocaAd,hocaSoyad,hocaNo)
values('Ferhat','Per�in',5)

insert into bilgisayar.notlar(ogrID,dersID,hocaID,Vize,Final)
values(170111006,2,5,60,80)

Create Schema hukuk
go

create table hukuk.ogrenci
(
ogrID int primary key identity(1,1),
ogrNo int,
ogrAd nvarchar(50),
ogrSoyad nvarchar(50),
)

create table hukuk.hoca
(
hocaID int primary key identity(1,1),
hocaNo int,
hocaAd nvarchar(50),
hocaSoyad nvarchar(50),

)

create table hukuk.ders
(
dersID int primary key identity(1,1),
dersNo int,
dersIsim nvarchar(50),

)

create table hukuk.notlar
(
notID int primary key identity(1,1),
ogrID int,
dersID int,
hocaID int,
Vize int,
Final int,
)

insert into hukuk.ogrenci(ogrAd,ogrSoyad,ogrNo)
values('Mustafa','Akta�',120)

insert into hukuk.ders(dersIsim,dersNo)
values('Hukuk',2)

insert into hukuk.hoca(hocaAd,hocaSoyad,hocaNo)
values('Murat','Ta�',11)

insert into hukuk.notlar(ogrID,dersID,hocaID,Vize,Final)
values(120,2,11,60,50)

Create Schema tarih
go

create table tarih.ogrenci
(
ogrID int primary key identity(1,1),
ogrNo int,
ogrAd nvarchar(50),
ogrSoyad nvarchar(50),
)

create table tarih.hoca
(
hocaID int primary key identity(1,1),
hocaNo int,
hocaAd nvarchar(50),
hocaSoyad nvarchar(50),

)

create table tarih.ders
(
dersID int primary key identity(1,1),
dersNo int,
dersIsim nvarchar(50),

)

create table tarih.notlar
(
notID int primary key identity(1,1),
ogrID int,
dersID int,
hocaID int,
Vize int,
Final int,
)

insert into tarih.ogrenci(ogrAd,ogrSoyad,ogrNo)
values('Yekta','Pusat',110)

insert into tarih.ders(dersIsim,dersNo)
values('Tarih',2)

insert into tarih.hoca(hocaAd,hocaSoyad,hocaNo)
values('Burak','Temel',11)

insert into tarih.notlar(ogrID,dersID,hocaID,Vize,Final)
values(110,2,11,40,50)


select * from tarih.ogrenci



Create View BilgisayarBolumu
as
Select ogrAd,ogrSoyad,ogrNo,dersIsim,dersNo,hocaNo,hocaAd,hocaSoyad,notID,Vize,Final
from bilgisayar.notlar as n
join bilgisayar.ogrenci as o on n.ogrID=o.ogrID
join bilgisayar.hoca as h on h.hocaID=n.hocaID
join bilgisayar.ders as d on d.dersID=n.dersID

select * from BilgisayarBolumu




Create View FelsefeBolumu
as
Select ogrAd,ogrSoyad,ogrNo
from felsefe.ogrenci

select * from FelsefeBolumu


ALTER VIEW numaras�10danbuyukogrencileribul

AS

SELECT ogrAd, ogrNo FROM Bilgisayar.ogrenci WHERE ogrNo>17

drop view numaras�10danbuyukogrencileribul



Create table ogr
(
ogrNo int,
ogrAd nvarchar(50),
ogrSoyad nvarchar(50)
)

create clustered index ix_ogr_Ad
on ogr (ogrAd)



create nonclustered index ix_No
on ogr (ogrNo)

create nonclustered index ix_Soyad
on ogr(ogrSoyad)
