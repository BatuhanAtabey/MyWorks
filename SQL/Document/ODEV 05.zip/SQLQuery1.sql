create database batuhan132
use batuhan132

create table arabalar(
araba_id int identity (1,1) primary key,
araba_ad nvarchar(50),
araba_uretici nvarchar(50),
araba_yil int,

)

create table ureticiler(
uretici_id int identity(1,1) primary key,
uretici_ad nvarchar(50),
araba_id int,
)

insert into arabalar (araba_ad,araba_uretici,araba_yil) VALUES
('BWMx7','BWM',2007),
('MBusinnes','Mersedes',2018),
('Auodia8','Auodi',2000),
('JaguarJeep','Jaguar',2005),
('WWBusines','Wolswogen',2009)

insert into ureticiler(uretici_ad,araba_id) VALUES
('BWM',1),
('Mersede',2),
('Aoudi',3),
('Jaguar',4),
('Wolswogen',5)


create proc yilp
 @yil int
 as
 begin
 select * from arabalar where araba_yil=@yil
 end

 exec yilp 2007



 create trigger Trigger�nsert
 for insert 
 as begin
 declare @b int
 select @b=araba_id from insert into ureticiler (uretici_id,araba_id) VALUES (1,@b)


create trigger TriggerDelete
on Products
after delete
as
select * from arabalar


create trigger TriggerUpdate
on Products
after delete
as
select * from arabalar where araba_yil=2007 where  araba_id=5